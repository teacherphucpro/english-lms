import React, { useState } from 'react';
import { BookOpen, GraduationCap, User, Mail, Phone, Lock, Calendar, Globe, BookMarked } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (role: 'teacher' | 'student') => void;
}

export default function AuthScreen({ onLogin }: AuthScreenProps) {
  const [isTeacherLogin, setIsTeacherLogin] = useState(false);
  const [isStudentLogin, setIsStudentLogin] = useState(false);

  return (
    <div className="min-h-screen flex w-full bg-gray-50 font-sans text-gray-800">
      
      {/* LEFT SIDE: TEACHER */}
      <div className="flex-1 flex flex-col justify-center px-12 py-12 lg:px-24 bg-white relative border-r border-gray-200">
        <div className="max-w-md w-full mx-auto">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 mb-6">
              <GraduationCap className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 tracking-tight">Dành cho Giáo viên</h2>
            <p className="mt-3 text-gray-500">Quản lý lớp học, bài tập và học sinh chuyên nghiệp.</p>
          </div>

          {!isTeacherLogin ? (
            <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onLogin('teacher'); }}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Họ và tên</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                    </div>
                    <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="Nguyễn Văn A" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tuổi</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Calendar className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                    </div>
                    <input type="number" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="30" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="tel" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="0901234567" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="email" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="giaovien@example.com" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tên người dùng</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="giaovien_01" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="password" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="••••••••" />
                </div>
              </div>

              <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors mt-6">
                Đăng ký Giáo viên
              </button>
            </form>
          ) : (
            <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onLogin('teacher'); }}>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tên người dùng</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="giaovien_01" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="password" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors" placeholder="••••••••" />
                </div>
              </div>

              <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors mt-6">
                Đăng nhập
              </button>
            </form>
          )}

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsTeacherLogin(!isTeacherLogin)}
              className="text-sm font-medium text-blue-600 hover:text-blue-500 transition-colors"
            >
              {isTeacherLogin ? "Chưa có tài khoản? Đăng ký ngay" : "Đã có tài khoản? Đăng nhập ngay"}
            </button>
          </div>
        </div>
      </div>

      {/* RIGHT SIDE: STUDENT/PARENT */}
      <div className="flex-1 flex flex-col justify-center px-12 py-12 lg:px-24 bg-[#F9FAFB] relative">
        {/* Decorative elements */}
        <div className="absolute top-12 right-12 text-emerald-200 opacity-50">
          <Globe className="w-24 h-24 stroke-[1]" />
        </div>
        <div className="absolute bottom-12 left-12 text-orange-200 opacity-50">
          <BookMarked className="w-20 h-20 stroke-[1]" />
        </div>

        <div className="max-w-md w-full mx-auto relative z-10">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 mb-6 shadow-sm">
              <BookOpen className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 tracking-tight">Dành cho Học sinh & Phụ huynh</h2>
            <p className="mt-3 text-gray-500">Học tập vui vẻ, theo dõi tiến độ dễ dàng.</p>
          </div>

          {!isStudentLogin ? (
            <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onLogin('student'); }}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Họ và tên</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                    </div>
                    <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="Trần Văn B" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tuổi</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Calendar className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                    </div>
                    <input type="number" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="12" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tên người dùng</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="hocsinh_01" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="password" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="••••••••" />
                </div>
              </div>

              <div className="pt-2 border-t border-gray-200 mt-4">
                <p className="text-xs text-gray-500 mb-3 font-medium uppercase tracking-wider">Thông tin liên hệ (Tùy chọn)</p>
                <div className="space-y-4">
                  <div>
                    <label className="flex justify-between text-sm font-medium text-gray-700 mb-1">
                      <span>Email</span>
                      <span className="text-gray-400 font-normal">(Không bắt buộc)</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                      </div>
                      <input type="email" className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="phuhuynh@example.com" />
                    </div>
                  </div>

                  <div>
                    <label className="flex justify-between text-sm font-medium text-gray-700 mb-1">
                      <span>Số điện thoại</span>
                      <span className="text-gray-400 font-normal">(Không bắt buộc)</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                      </div>
                      <input type="tel" className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="0901234567" />
                    </div>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors mt-6">
                Đăng ký Học sinh
              </button>
            </form>
          ) : (
            <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onLogin('student'); }}>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tên người dùng</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="text" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="hocsinh_01" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mật khẩu</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400 stroke-[1.5]" />
                  </div>
                  <input type="password" required className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm transition-colors bg-white" placeholder="••••••••" />
                </div>
              </div>

              <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors mt-6">
                Đăng nhập
              </button>
            </form>
          )}

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsStudentLogin(!isStudentLogin)}
              className="text-sm font-medium text-emerald-600 hover:text-emerald-500 transition-colors"
            >
              {isStudentLogin ? "Chưa có tài khoản? Đăng ký ngay" : "Đã có tài khoản? Đăng nhập ngay"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
