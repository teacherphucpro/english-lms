import React, { useState } from 'react';
import { 
  BookOpen, 
  School, 
  ClipboardList, 
  Folder, 
  GraduationCap, 
  Bell, 
  Search, 
  User, 
  MoreVertical,
  Plus,
  Clock,
  Users,
  Calendar,
  ChevronRight,
  TrendingUp,
  LogOut,
  ChevronDown,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  PlayCircle
} from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import AuthScreen from './components/AuthScreen';

const navItems = [
  { id: 'classes', label: 'Lớp học', icon: BookOpen },
  { id: 'schools', label: 'Trường học', icon: School },
  { id: 'assignments', label: 'Bài tập', icon: ClipboardList },
  { id: 'materials', label: 'Tài liệu', icon: Folder },
  { id: 'grades', label: 'Điểm', icon: GraduationCap },
  { id: 'notifications', label: 'Thông báo', icon: Bell },
];

// --- MOCK DATA FOR TEACHER ---
const mockNotificationsTeacher = [
  { id: 1, title: 'Lịch thi giữa kỳ tháng 10', time: '2 giờ trước', type: 'important', icon: AlertCircle, color: 'text-orange-500', bg: 'bg-orange-50' },
  { id: 2, title: 'Cập nhật tài liệu: Unit 5 - Vocabulary', time: '5 giờ trước', type: 'info', icon: BookOpen, color: 'text-blue-500', bg: 'bg-blue-50' },
  { id: 3, title: 'Nhắc nhở: Chấm điểm bài tập Writing Task 1', time: '1 ngày trước', type: 'task', icon: ClipboardList, color: 'text-emerald-500', bg: 'bg-emerald-50' },
];

const classList = [
  { id: '6A1', name: 'Lớp 6A1' },
  { id: '7B2', name: 'Lớp 7B2' },
  { id: 'IELTS', name: 'IELTS Foundation' },
];

const attendanceData = [
  { name: 'Có mặt', value: 85 },
  { name: 'Vắng phép', value: 10 },
  { name: 'Vắng không phép', value: 5 },
];
const ATTENDANCE_COLORS = ['#10b981', '#f59e0b', '#ef4444'];

const skillsData = [
  { name: 'Listening', score: 7.5 },
  { name: 'Speaking', score: 6.8 },
  { name: 'Reading', score: 8.2 },
  { name: 'Writing', score: 6.5 },
];

// --- MOCK DATA FOR STUDENT ---
const mockNotificationsStudent = [
  { id: 1, title: 'Bài tập Writing Unit 5 hạn nộp 22:00 hôm nay', time: '1 giờ trước', type: 'important', icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50' },
  { id: 2, title: 'Giáo viên Nguyễn Văn A đã chấm điểm bài Speaking Test', time: '3 giờ trước', type: 'info', icon: CheckCircle2, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  { id: 3, title: 'Cô giáo gửi tin nhắn: "Nhớ ôn tập từ vựng nhé!"', time: 'Hôm qua', type: 'message', icon: MessageSquare, color: 'text-blue-500', bg: 'bg-blue-50' },
];

const studentProgressData = [
  { week: 'Tuần 1', score: 7.0 },
  { week: 'Tuần 2', score: 7.5 },
  { week: 'Tuần 3', score: 7.2 },
  { week: 'Tuần 4', score: 8.0 },
];

const recentGrades = [
  { id: 1, name: 'Unit 4 Reading', score: 8.5, date: '12/10/2023' },
  { id: 2, name: 'Unit 4 Listening', score: 7.0, date: '10/10/2023' },
  { id: 3, name: 'Speaking Test 1', score: 8.0, date: '08/10/2023' },
  { id: 4, name: 'Unit 5 Vocabulary', score: 9.0, date: '05/10/2023' },
  { id: 5, name: 'Unit 5 Grammar', score: 8.5, date: '01/10/2023' },
];

const incompleteAssignments = [
  { id: 1, name: 'Writing Unit 5', due: 'Hôm nay, 22:00', type: 'Writing' },
  { id: 2, name: 'Reading Comprehension Test', due: 'Ngày mai, 23:59', type: 'Reading' },
];

export default function App() {
  const [userRole, setUserRole] = useState<'teacher' | 'student' | null>(null);
  const [activeTab, setActiveTab] = useState('classes');
  
  // Teacher state
  const [selectedClass, setSelectedClass] = useState('6A1');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  if (!userRole) {
    return <AuthScreen onLogin={(role) => setUserRole(role)} />;
  }

  const isTeacher = userRole === 'teacher';
  const primaryColor = isTeacher ? 'blue' : 'emerald';

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-gray-800">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-gray-100">
          <div className={`flex items-center gap-2 text-${primaryColor}-600`}>
            <BookOpen className="w-8 h-8 stroke-[1.5]" />
            <span className="text-xl font-bold tracking-tight">EnglishLMS</span>
          </div>
        </div>
        
        <div className="flex-1 py-6 px-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? `bg-${primaryColor}-50 text-${primaryColor}-700 font-medium` 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
                }`}
              >
                <Icon className={`w-5 h-5 stroke-[1.5] ${isActive ? `text-${primaryColor}-600` : 'text-gray-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 px-4 py-2">
            <div className={`w-10 h-10 rounded-full bg-${primaryColor}-100 flex items-center justify-center text-${primaryColor}-600 font-bold`}>
              {isTeacher ? 'GV' : 'HS'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">{isTeacher ? 'Nguyễn Văn A' : 'Trần Văn B'}</p>
              <p className="text-xs text-gray-500 truncate">{isTeacher ? 'Giáo viên Tiếng Anh' : 'Học sinh Lớp 6A1'}</p>
            </div>
            <button onClick={() => setUserRole(null)} className="p-2 text-gray-400 hover:text-red-500 transition-colors" title="Đăng xuất">
              <LogOut className="w-5 h-5 stroke-[1.5]" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0">
          <div className={`flex items-center bg-gray-50 rounded-xl px-4 py-2 w-96 border border-gray-200 focus-within:ring-2 focus-within:ring-${primaryColor}-500 focus-within:bg-white transition-all`}>
            <Search className="w-4 h-4 text-gray-400 stroke-[1.5]" />
            <input 
              type="text" 
              placeholder="Tìm kiếm lớp học, học sinh, bài tập..." 
              className="bg-transparent border-none outline-none ml-2 w-full text-sm placeholder-gray-400 text-gray-800"
            />
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors">
              <Bell className="w-5 h-5 stroke-[1.5]" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-orange-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-px bg-gray-200"></div>
            <button className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-800">
              <span>Học kỳ 1, 2023-2024</span>
              <ChevronRight className="w-4 h-4 rotate-90 stroke-[1.5]" />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-8">
          {activeTab === 'classes' ? (
            <div className="max-w-6xl mx-auto space-y-8">
              
              {/* Notifications Section */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-800">
                    {isTeacher ? 'Thông báo Mới nhất' : 'Nhắc nhở Hôm nay'}
                  </h2>
                  <button className={`text-sm font-medium text-${primaryColor}-600 hover:text-${primaryColor}-700`}>Xem tất cả</button>
                </div>
                <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                  <ul className="divide-y divide-gray-100">
                    {(isTeacher ? mockNotificationsTeacher : mockNotificationsStudent).map((note) => {
                      const Icon = note.icon;
                      return (
                        <li key={note.id} className="p-4 hover:bg-gray-50 transition-colors flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${note.bg} ${note.color}`}>
                            <Icon className="w-5 h-5 stroke-[1.5]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900">{note.title}</p>
                            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {note.time}
                            </p>
                          </div>
                          <button className="text-gray-400 hover:text-gray-600 p-2">
                            <ChevronRight className="w-4 h-4 stroke-[1.5]" />
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </section>

              {/* Statistics Section */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-800">
                    {isTeacher ? 'Thống kê Hiệu suất Lớp học' : 'Tiến độ học tập của Trần Văn B'}
                  </h2>
                  
                  {isTeacher && (
                    <div className="relative">
                      <button 
                        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                        className="flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
                      >
                        <span>{classList.find(c => c.id === selectedClass)?.name}</span>
                        <ChevronDown className={`w-4 h-4 stroke-[1.5] transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>
                      
                      {isDropdownOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-10 py-1">
                          {classList.map(cls => (
                            <button
                              key={cls.id}
                              onClick={() => {
                                setSelectedClass(cls.id);
                                setIsDropdownOpen(false);
                              }}
                              className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${selectedClass === cls.id ? 'text-blue-600 font-medium bg-blue-50/50' : 'text-gray-700'}`}
                            >
                              {cls.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {isTeacher ? (
                  // TEACHER STATISTICS
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Attendance Pie Chart */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col">
                      <h3 className="text-sm font-medium text-gray-500 mb-4">Tỷ lệ chuyên cần trung bình</h3>
                      <div className="flex-1 flex items-center justify-center relative min-h-[200px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={attendanceData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              {attendanceData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={ATTENDANCE_COLORS[index % ATTENDANCE_COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip 
                              formatter={(value) => `${value}%`}
                              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                        <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
                          <span className="text-2xl font-bold text-gray-800">85%</span>
                          <span className="text-xs text-gray-500">Có mặt</span>
                        </div>
                      </div>
                      <div className="flex justify-center gap-4 mt-4">
                        {attendanceData.map((entry, index) => (
                          <div key={entry.name} className="flex items-center gap-1.5">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ATTENDANCE_COLORS[index] }}></div>
                            <span className="text-xs text-gray-600">{entry.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Skills Bar Chart */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-2 flex flex-col">
                      <h3 className="text-sm font-medium text-gray-500 mb-4">Điểm trung bình theo 4 kỹ năng</h3>
                      <div className="flex-1 min-h-[200px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={skillsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                            <XAxis 
                              dataKey="name" 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fill: '#6b7280', fontSize: 12 }}
                              dy={10}
                            />
                            <YAxis 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fill: '#6b7280', fontSize: 12 }}
                              domain={[0, 10]}
                            />
                            <Tooltip 
                              cursor={{ fill: '#f3f4f6' }}
                              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                            />
                            <Bar dataKey="score" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={50} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Homework Completion Stat */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-3 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                          <CheckCircle2 className="w-7 h-7 stroke-[1.5]" />
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Học sinh hoàn thành BTVN (Tuần này)</h3>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-3xl font-bold text-gray-800">32/35</span>
                            <span className="text-sm font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">+12% so với tuần trước</span>
                          </div>
                        </div>
                      </div>
                      <button className="text-sm font-medium text-blue-600 hover:text-blue-700 bg-blue-50 px-4 py-2 rounded-lg transition-colors">
                        Xem chi tiết
                      </button>
                    </div>
                  </div>
                ) : (
                  // STUDENT STATISTICS
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Overall Progress Bar */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-3 flex flex-col justify-center">
                      <div className="flex justify-between items-end mb-2">
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Tỷ lệ hoàn thành bài tập (Tháng này)</h3>
                          <p className="text-3xl font-bold text-gray-800 mt-1">85%</p>
                        </div>
                        <span className="text-sm font-medium text-emerald-600">Tuyệt vời! Tiếp tục phát huy nhé.</span>
                      </div>
                      <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden mt-2">
                        <div className="h-full bg-emerald-500 rounded-full transition-all duration-1000" style={{ width: '85%' }}></div>
                      </div>
                    </div>

                    {/* Line Chart: Average Score */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-2 flex flex-col">
                      <h3 className="text-sm font-medium text-gray-500 mb-4">Điểm số trung bình theo tuần</h3>
                      <div className="flex-1 min-h-[200px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={studentProgressData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                            <XAxis 
                              dataKey="week" 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fill: '#6b7280', fontSize: 12 }}
                              dy={10}
                            />
                            <YAxis 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fill: '#6b7280', fontSize: 12 }}
                              domain={[0, 10]}
                            />
                            <Tooltip 
                              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                            />
                            <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 6 }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Recent Grades Table */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col">
                      <h3 className="text-sm font-medium text-gray-500 mb-4">5 đầu điểm gần nhất</h3>
                      <div className="flex-1 overflow-y-auto">
                        <ul className="space-y-4">
                          {recentGrades.map((grade) => (
                            <li key={grade.id} className="flex items-center justify-between">
                              <div>
                                <p className="text-sm font-medium text-gray-800">{grade.name}</p>
                                <p className="text-xs text-gray-500">{grade.date}</p>
                              </div>
                              <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 font-bold text-sm">
                                {grade.score}
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Incomplete Assignments */}
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm lg:col-span-3">
                      <h3 className="text-sm font-medium text-gray-500 mb-4">Bài tập chưa hoàn thành</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {incompleteAssignments.map((assignment) => (
                          <div key={assignment.id} className="flex items-center justify-between p-4 rounded-xl border border-orange-200 bg-orange-50/50">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center text-orange-600">
                                <ClipboardList className="w-5 h-5 stroke-[1.5]" />
                              </div>
                              <div>
                                <p className="text-sm font-bold text-gray-800">{assignment.name}</p>
                                <p className="text-xs font-medium text-orange-600 mt-0.5 flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  Hạn: {assignment.due}
                                </p>
                              </div>
                            </div>
                            <button className="flex items-center gap-1.5 bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-600 transition-colors shadow-sm">
                              <PlayCircle className="w-4 h-4" />
                              Làm ngay
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </section>

            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 space-y-4">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center">
                <BookOpen className="w-10 h-10 text-gray-300 stroke-[1.5]" />
              </div>
              <p className="text-lg font-medium text-gray-500">Chức năng đang được phát triển</p>
              <p className="text-sm">Vui lòng chọn "Lớp học" để xem giao diện chính.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
